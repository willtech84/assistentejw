-- Campos de qualificação e perfil dos estudantes, mapeados 1:1 das
-- colunas da planilha real usada pela congregação (Estudantes.xlsx):
-- Leitura, Ajudante, Iniciando, Cultivando o interesse, Explicando,
-- Discípulos, Discurso, Frequência, Responsabilidade, Pioneiro,
-- Gênero, Nascimento, Batismo (telefone/email/observações já existiam).
--
-- Os campos "qualificado_*" são flags booleanas: indicam para quais
-- tipos de designação aquele estudante pode ser escalado. Isso é o
-- que a planilha representa com "1" nas colunas (célula vazia = não
-- qualificado). Usados para filtrar o <select> de estudante ao criar
-- uma designação de um tipo específico (ex: só mostrar quem tem
-- qualificado_discurso=true ao criar uma designação de Discurso).

alter table estudantes
  add column qualificado_leitura boolean not null default false,
  add column qualificado_ajudante boolean not null default false,
  add column qualificado_iniciando boolean not null default false,
  add column qualificado_cultivando boolean not null default false,
  add column qualificado_explicando boolean not null default false,
  add column qualificado_discipulos boolean not null default false,
  add column qualificado_discurso boolean not null default false,

  -- Publicador / Batizado / Estudante / Servo ministerial / Ancião
  add column responsabilidade text not null default '',
  add column pioneiro boolean not null default false,
  add column genero text not null default '' check (genero in ('', 'M', 'F')),
  add column nascimento date,
  add column batismo date;
