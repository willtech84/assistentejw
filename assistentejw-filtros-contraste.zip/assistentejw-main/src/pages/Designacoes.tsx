import { useEffect, useState } from "react";
import { supabase } from "../lib/supabase";
import type { Designacao, Configuracoes } from "../lib/database.types";
import PageHeader from "../components/PageHeader";
import { abrirWhatsapp, montarMensagemDesignacao } from "../services/whatsapp";
import {
  carregarEstudantesDoUsuario,
  type EstudanteBasico,
} from "../services/estudanteMatch";
import { compartilharOuBaixarS89 } from "../services/s89Generate";
import { TIPOS_DESIGNACAO } from "../lib/constants";

export default function Designacoes() {
  const [lista, setLista] = useState<Designacao[]>([]);
  const [config, setConfig] = useState<Configuracoes | null>(null);
  const [estudantes, setEstudantes] = useState<EstudanteBasico[]>([]);
  const [carregando, setCarregando] = useState(true);
  const [editando, setEditando] = useState<Partial<Designacao> | null>(null);
  const [gerandoPdfId, setGerandoPdfId] = useState<string | null>(null);
  const [erroPdf, setErroPdf] = useState<string | null>(null);

  // filtros
  const [filtroDataInicio, setFiltroDataInicio] = useState("");
  const [filtroDataFim, setFiltroDataFim] = useState("");
  const [filtroPessoa, setFiltroPessoa] = useState("");
  const [filtroTipo, setFiltroTipo] = useState("");

  // fila de envio em lote — um item por vez, avança por clique (evita
  // bloqueio de pop-up do navegador e deixa revisar cada envio antes
  // de marcar como enviado)
  const [filaEnvio, setFilaEnvio] = useState<Designacao[] | null>(null);

  async function carregar() {
    setCarregando(true);
    const hoje = new Date();
    hoje.setDate(hoje.getDate() - 60); // janela maior, pra filtros de mês funcionarem

    const [{ data: designacoes }, { data: cfg }, listaEstudantes] =
      await Promise.all([
        supabase
          .from("designacoes")
          .select("*")
          .gte("data_reuniao", hoje.toISOString().slice(0, 10))
          .order("data_reuniao", { ascending: true }),
        supabase.from("configuracoes").select("*").maybeSingle(),
        carregarEstudantesDoUsuario(),
      ]);

    setLista(designacoes ?? []);
    setConfig(cfg ?? null);
    setEstudantes(listaEstudantes);
    setCarregando(false);
  }

  useEffect(() => {
    carregar();
  }, []);

  async function salvar(e: React.FormEvent) {
    e.preventDefault();
    if (!editando?.data_reuniao) return;

    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    const estudanteSelecionado = estudantes.find(
      (e) => e.id === editando.estudante_id
    );
    const payload = {
      ...editando,
      estudante: estudanteSelecionado?.nome ?? editando.estudante ?? "",
      user_id: user.id,
    };

    if (editando.id) {
      await supabase.from("designacoes").update(payload).eq("id", editando.id);
    } else {
      await supabase.from("designacoes").insert(payload);
    }

    setEditando(null);
    carregar();
  }

  async function marcarEnviada(d: Designacao) {
    await supabase
      .from("designacoes")
      .update({ whatsapp_enviado: true })
      .eq("id", d.id);
    carregar();
  }

  async function enviar(d: Designacao) {
    if (!d.estudante) return;

    if (!d.estudante_id) {
      alert(
        `"${d.estudante}" não está vinculado a um estudante cadastrado. ` +
          `Edite esta designação e selecione o estudante na lista antes de enviar.`
      );
      return;
    }

    const mensagem = montarMensagemDesignacao({
      mensagemPadrao: config?.mensagem_padrao ?? "",
      nomeEstudante: d.estudante,
      tipo: d.tipo,
      semana: d.semana,
    });

    // Telefone vem do cadastro via estudante_id (FK) — não mais por
    // casamento de nome em tempo de execução, que falhava
    // silenciosamente com nomes duplicados ou digitação diferente.
    const { data: estudante } = await supabase
      .from("estudantes")
      .select("telefone")
      .eq("id", d.estudante_id)
      .maybeSingle();

    if (!estudante?.telefone) {
      alert(
        `Telefone de "${d.estudante}" não encontrado no cadastro de estudantes.`
      );
      return;
    }

    abrirWhatsapp(estudante.telefone, mensagem);
    if (config?.confirmar_antes_enviar !== false) {
      if (confirm("Marcar esta designação como enviada?")) {
        await marcarEnviada(d);
      }
    } else {
      await marcarEnviada(d);
    }
  }

  async function handleGerarS89(d: Designacao) {
    setErroPdf(null);
    setGerandoPdfId(d.id);
    try {
      await compartilharOuBaixarS89(d);
    } catch (err) {
      setErroPdf(
        err instanceof Error ? err.message : "Erro ao gerar o PDF da designação."
      );
    } finally {
      setGerandoPdfId(null);
    }
  }

  function aplicarFiltroRapido(tipo: "semana" | "mes" | "todos") {
    if (tipo === "todos") {
      setFiltroDataInicio("");
      setFiltroDataFim("");
      return;
    }
    const hoje = new Date();
    if (tipo === "semana") {
      const diaSemana = (hoje.getDay() + 6) % 7; // 0 = segunda
      const inicio = new Date(hoje);
      inicio.setDate(hoje.getDate() - diaSemana);
      const fim = new Date(inicio);
      fim.setDate(inicio.getDate() + 6);
      setFiltroDataInicio(inicio.toISOString().slice(0, 10));
      setFiltroDataFim(fim.toISOString().slice(0, 10));
    } else {
      const inicio = new Date(hoje.getFullYear(), hoje.getMonth(), 1);
      const fim = new Date(hoje.getFullYear(), hoje.getMonth() + 1, 0);
      setFiltroDataInicio(inicio.toISOString().slice(0, 10));
      setFiltroDataFim(fim.toISOString().slice(0, 10));
    }
  }

  const listaFiltrada = lista.filter((d) => {
    if (filtroDataInicio && d.data_reuniao < filtroDataInicio) return false;
    if (filtroDataFim && d.data_reuniao > filtroDataFim) return false;
    if (filtroPessoa && d.estudante !== filtroPessoa && d.ajudante !== filtroPessoa)
      return false;
    if (filtroTipo && d.tipo !== filtroTipo) return false;
    return true;
  });

  const pessoasDisponiveis = [
    ...new Set(
      lista.flatMap((d) => [d.estudante, d.ajudante].filter(Boolean))
    ),
  ].sort((a, b) => a.localeCompare(b, "pt-BR"));

  const tiposDisponiveis = [...new Set(lista.map((d) => d.tipo).filter(Boolean))].sort(
    (a, b) => a.localeCompare(b, "pt-BR")
  );

  function iniciarEnvioLote() {
    const pendentes = listaFiltrada.filter(
      (d) => !d.whatsapp_enviado && d.estudante_id
    );
    if (pendentes.length === 0) {
      alert(
        "Não há designações pendentes de envio (com estudante vinculado) no filtro atual."
      );
      return;
    }
    setFilaEnvio(pendentes);
  }

  async function enviarProximoDaFila() {
    if (!filaEnvio || filaEnvio.length === 0) return;
    const atual = filaEnvio[0];
    await enviar(atual);
    setFilaEnvio((fila) => {
      const restante = (fila ?? []).slice(1);
      return restante.length > 0 ? restante : null;
    });
  }

  const porSemana = agrupar(listaFiltrada);

  return (
    <div>
      <PageHeader
        title="Designações"
        action={
          <div className="flex items-center gap-2">
            <button
              onClick={iniciarEnvioLote}
              className="rounded-lg border border-emerald-600 px-3 py-1.5 text-sm font-medium text-emerald-700 hover:bg-emerald-50"
            >
              Enviar todos
            </button>
            <button
              onClick={() => setEditando({ sala: "Principal" })}
              className="rounded-lg bg-indigo-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-indigo-700"
            >
              + Nova
            </button>
          </div>
        }
      />

      <div className="space-y-6 p-4 md:p-6">
        <div className="rounded-xl border border-slate-200 bg-white p-4">
          <div className="mb-3 flex flex-wrap gap-2">
            <button
              onClick={() => aplicarFiltroRapido("semana")}
              className="rounded-full border border-slate-300 px-3 py-1 text-xs text-slate-600 hover:bg-slate-50"
            >
              Esta semana
            </button>
            <button
              onClick={() => aplicarFiltroRapido("mes")}
              className="rounded-full border border-slate-300 px-3 py-1 text-xs text-slate-600 hover:bg-slate-50"
            >
              Este mês
            </button>
            <button
              onClick={() => aplicarFiltroRapido("todos")}
              className="rounded-full border border-slate-300 px-3 py-1 text-xs text-slate-600 hover:bg-slate-50"
            >
              Todas as datas
            </button>
          </div>
          <div className="grid gap-3 sm:grid-cols-4">
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-500">
                De
              </label>
              <input
                type="date"
                value={filtroDataInicio}
                onChange={(e) => setFiltroDataInicio(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-500">
                Até
              </label>
              <input
                type="date"
                value={filtroDataFim}
                onChange={(e) => setFiltroDataFim(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none"
              />
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-500">
                Pessoa
              </label>
              <select
                value={filtroPessoa}
                onChange={(e) => setFiltroPessoa(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none"
              >
                <option value="">Todas</option>
                {pessoasDisponiveis.map((p) => (
                  <option key={p} value={p}>
                    {p}
                  </option>
                ))}
              </select>
            </div>
            <div>
              <label className="mb-1 block text-xs font-medium text-slate-500">
                Designação
              </label>
              <select
                value={filtroTipo}
                onChange={(e) => setFiltroTipo(e.target.value)}
                className="w-full rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none"
              >
                <option value="">Todas</option>
                {tiposDisponiveis.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>
          </div>
        </div>

        {filaEnvio && (
          <div className="flex flex-wrap items-center justify-between gap-3 rounded-xl border border-emerald-200 bg-emerald-50 p-4">
            <div>
              <p className="text-sm font-medium text-emerald-900">
                Envio em lote — {filaEnvio.length} restante
                {filaEnvio.length > 1 ? "s" : ""}
              </p>
              <p className="text-xs text-emerald-700">
                Próximo: {filaEnvio[0].estudante} — {filaEnvio[0].tipo}
              </p>
            </div>
            <div className="flex gap-2">
              <button
                onClick={() => setFilaEnvio(null)}
                className="rounded-lg px-3 py-1.5 text-xs text-emerald-800 hover:bg-emerald-100"
              >
                Cancelar
              </button>
              <button
                onClick={enviarProximoDaFila}
                className="rounded-lg bg-emerald-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-emerald-700"
              >
                Enviar próximo
              </button>
            </div>
          </div>
        )}

        {erroPdf && (
          <p className="rounded-lg bg-red-50 px-3 py-2 text-sm text-red-700">
            {erroPdf}
          </p>
        )}
        {carregando ? (
          <p className="text-sm text-slate-500">Carregando...</p>
        ) : listaFiltrada.length === 0 ? (
          <p className="text-sm text-slate-500">
            {lista.length === 0
              ? 'Nenhuma designação cadastrada. Crie uma manualmente ou importe uma planilha S-140 em "PDFs e Importação".'
              : "Nenhuma designação encontrada com esses filtros."}
          </p>
        ) : (
          Object.entries(porSemana).map(([semana, itens]) => (
            <div key={semana}>
              <h2 className="mb-2 text-sm font-semibold text-slate-500">
                {new Date(itens[0].data_reuniao + "T00:00:00").toLocaleDateString(
                  "pt-BR",
                  { weekday: "long", day: "2-digit", month: "long" }
                )}
                {semana ? ` — ${semana}` : ""}
              </h2>
              <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
                {itens.map((d) => (
                  <div
                    key={d.id}
                    className="flex items-center justify-between border-b border-slate-100 px-4 py-3 last:border-0"
                  >
                    <div>
                      <p className="text-sm font-medium text-slate-900">
                        {d.tipo || "(sem tipo)"}
                      </p>
                      <p className="text-sm text-slate-500">
                        {d.estudante || "—"}
                        {d.ajudante ? ` + ${d.ajudante}` : ""}
                        {d.estudante && !d.estudante_id && (
                          <span className="ml-2 rounded-full bg-amber-100 px-2 py-0.5 text-xs text-amber-700">
                            sem vínculo
                          </span>
                        )}
                      </p>
                    </div>
                    <div className="flex flex-wrap items-center justify-end gap-2">
                      {d.whatsapp_enviado ? (
                        <span className="rounded-full bg-emerald-100 px-2 py-0.5 text-xs text-emerald-700">
                          Enviado
                        </span>
                      ) : (
                        <button
                          onClick={() => enviar(d)}
                          className="rounded-lg bg-emerald-600 px-2 py-1 text-xs font-medium text-white hover:bg-emerald-700"
                        >
                          Enviar WhatsApp
                        </button>
                      )}
                      <button
                        onClick={() => handleGerarS89(d)}
                        disabled={gerandoPdfId === d.id}
                        className="rounded-lg border border-slate-300 px-2 py-1 text-xs font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-50"
                      >
                        {gerandoPdfId === d.id ? "Gerando..." : "PDF S-89"}
                      </button>
                      <button
                        onClick={() => setEditando(d)}
                        className="text-xs text-indigo-600 hover:underline"
                      >
                        Editar
                      </button>
                    </div>
                  </div>
                ))}
              </div>
            </div>
          ))
        )}
      </div>

      {editando && (
        <div className="fixed inset-0 z-20 flex items-end justify-center bg-black/30 sm:items-center sm:p-4">
          <form
            onSubmit={salvar}
            className="w-full max-w-md space-y-4 rounded-t-2xl bg-white p-6 sm:rounded-2xl"
          >
            <h2 className="text-lg font-semibold text-slate-900">
              {editando.id ? "Editar designação" : "Nova designação"}
            </h2>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">
                Data da reunião
              </label>
              <input
                type="date"
                required
                value={editando.data_reuniao ?? ""}
                onChange={(e) =>
                  setEditando({ ...editando, data_reuniao: e.target.value })
                }
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none"
              />
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">
                Tipo de designação
              </label>
              <select
                required
                value={editando.tipo ?? ""}
                onChange={(e) =>
                  setEditando({ ...editando, tipo: e.target.value })
                }
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none"
              >
                <option value="" disabled>
                  Selecione...
                </option>
                {TIPOS_DESIGNACAO.map((t) => (
                  <option key={t} value={t}>
                    {t}
                  </option>
                ))}
              </select>
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">
                Estudante
              </label>
              <select
                required
                value={editando.estudante_id ?? ""}
                onChange={(e) =>
                  setEditando({ ...editando, estudante_id: e.target.value || null })
                }
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none"
              >
                <option value="" disabled>
                  Selecione...
                </option>
                {estudantes.map((e) => (
                  <option key={e.id} value={e.id}>
                    {e.nome}
                  </option>
                ))}
              </select>
              {estudantes.length === 0 && (
                <p className="mt-1 text-xs text-amber-600">
                  Nenhum estudante cadastrado ainda — cadastre em
                  "Estudantes" primeiro.
                </p>
              )}
            </div>
            <Campo
              label="Ajudante (opcional)"
              value={editando.ajudante ?? ""}
              onChange={(v) => setEditando({ ...editando, ajudante: v })}
            />
            <Campo
              label="Semana (ex: 11-17 de agosto)"
              value={editando.semana ?? ""}
              onChange={(v) => setEditando({ ...editando, semana: v })}
            />

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditando(null)}
                className="rounded-lg px-4 py-2 text-sm text-slate-600 hover:bg-slate-100"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700"
              >
                Salvar
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

function agrupar(lista: Designacao[]): Record<string, Designacao[]> {
  return lista.reduce<Record<string, Designacao[]>>((acc, d) => {
    const chave = d.data_reuniao;
    acc[chave] = acc[chave] ? [...acc[chave], d] : [d];
    return acc;
  }, {});
}

function Campo({
  label,
  value,
  onChange,
  required,
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  required?: boolean;
}) {
  return (
    <div>
      <label className="mb-1 block text-sm font-medium text-slate-700">
        {label}
      </label>
      <input
        value={value}
        required={required}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none"
      />
    </div>
  );
}
