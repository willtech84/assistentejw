import { useEffect, useRef, useState } from "react";
import { supabase } from "../lib/supabase";
import type { PdfRecebido } from "../lib/database.types";
import PageHeader from "../components/PageHeader";
import {
  carregarEstudantesDoUsuario,
  resolverEstudanteId,
  type EstudanteBasico,
} from "../services/estudanteMatch";
import { processarPdf } from "../services/pdfExtract";
import { obterPdfCompartilhado } from "../services/shareTarget";
import { importarS140, type DesignacaoS140 } from "../services/s140Import";
import { TIPOS_DESIGNACAO } from "../lib/constants";

interface LinhaS140Revisada extends DesignacaoS140 {
  estudante_id: string | null;
  ajudante_id: string | null;
}

export default function Pdfs() {
  const [lista, setLista] = useState<PdfRecebido[]>([]);
  const [estudantes, setEstudantes] = useState<EstudanteBasico[]>([]);
  const [carregando, setCarregando] = useState(true);
  const [importando, setImportando] = useState(false);
  const [extraindo, setExtraindo] = useState(false);
  const [mensagem, setMensagem] = useState<string | null>(null);
  const [linhasS140, setLinhasS140] = useState<LinhaS140Revisada[] | null>(null);
  const inputExcel = useRef<HTMLInputElement>(null);
  const inputPdf = useRef<HTMLInputElement>(null);

  async function carregar(): Promise<EstudanteBasico[]> {
    setCarregando(true);
    const [{ data }, listaEstudantes] = await Promise.all([
      supabase
        .from("pdfs_recebidos")
        .select("*")
        .order("recebido_em", { ascending: false }),
      carregarEstudantesDoUsuario(),
    ]);
    setLista(data ?? []);
    setEstudantes(listaEstudantes);
    setCarregando(false);
    return listaEstudantes;
  }

  useEffect(() => {
    // carrega a lista de estudantes ANTES de checar compartilhamento —
    // processarEEnviarPdf precisa da lista já disponível para sugerir o
    // estudante certo. Passamos a lista explicitamente (em vez de
    // depender do estado `estudantes`) para não pegar um valor
    // desatualizado — o setEstudantes acima só reflete no próximo
    // render, e este efeito roda antes disso.
    carregar().then((listaEstudantes) => {
      // Chegou aqui via "Compartilhar" de outro app (Web Share Target)?
      // O service worker já guardou o PDF na Cache Storage — busca e
      // processa exatamente como um upload manual.
      const params = new URLSearchParams(window.location.search);
      if (params.get("compartilhado") !== "1") return;

      // limpa a URL imediatamente para não tentar de novo num refresh
      window.history.replaceState({}, "", window.location.pathname);

      obterPdfCompartilhado().then((arquivo) => {
        if (arquivo) {
          setMensagem("PDF recebido por compartilhamento. Processando...");
          processarEEnviarPdf(arquivo, listaEstudantes);
        }
      });
    });
    // eslint-disable-next-line react-hooks/exhaustive-deps
  }, []);

  async function handleImportarExcel(e: React.ChangeEvent<HTMLInputElement>) {
    const arquivo = e.target.files?.[0];
    if (!arquivo) return;

    setImportando(true);
    setMensagem(null);
    try {
      const linhas = await importarS140(arquivo);
      if (linhas.length === 0) {
        setMensagem(
          'Não encontrei nenhuma designação nessa planilha. Confira se o arquivo é uma exportação da programação semanal (S-140) com o layout esperado ("DD/MM/AAAA | TEMA" no início de cada semana).'
        );
        return;
      }

      const listaEstudantes = await carregarEstudantesDoUsuario();
      const revisadas: LinhaS140Revisada[] = linhas.map((l) => ({
        ...l,
        estudante_id: resolverEstudanteId(l.estudante, listaEstudantes),
        ajudante_id: l.ajudante ? resolverEstudanteId(l.ajudante, listaEstudantes) : null,
      }));

      setEstudantes(listaEstudantes);
      setLinhasS140(revisadas);
      setMensagem(null);
    } catch (err) {
      setMensagem(
        `Erro ao importar: ${err instanceof Error ? err.message : String(err)}`
      );
    } finally {
      setImportando(false);
      if (inputExcel.current) inputExcel.current.value = "";
    }
  }

  function atualizarLinhaS140(indice: number, campo: "estudante_id" | "ajudante_id", valor: string) {
    setLinhasS140((atual) =>
      atual
        ? atual.map((l, i) => (i === indice ? { ...l, [campo]: valor || null } : l))
        : atual
    );
  }

  async function confirmarImportacaoS140() {
    if (!linhasS140) return;
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    setImportando(true);
    try {
      // evita duplicar ao reimportar a mesma planilha: pula linhas que
      // já existem exatamente iguais (mesma data + parte + sala + estudante)
      const dataMinima = linhasS140.reduce(
        (min, l) => (l.data_reuniao < min ? l.data_reuniao : min),
        linhasS140[0]?.data_reuniao ?? "1900-01-01"
      );
      const { data: existentes } = await supabase
        .from("designacoes")
        .select("data_reuniao, nome, sala, estudante")
        .gte("data_reuniao", dataMinima);

      const chave = (l: { data_reuniao: string; nome: string; sala: string; estudante: string }) =>
        `${l.data_reuniao}|${l.nome}|${l.sala}|${l.estudante}`;
      const existentesSet = new Set((existentes ?? []).map(chave));

      const paraInserir = linhasS140
        .filter((l) => !existentesSet.has(chave(l)))
        .map((l) => {
          const estudanteNome =
            estudantes.find((e) => e.id === l.estudante_id)?.nome ?? l.estudante;
          const ajudanteNome = l.ajudante_id
            ? estudantes.find((e) => e.id === l.ajudante_id)?.nome ?? l.ajudante
            : l.ajudante;
          return {
            user_id: user.id,
            data_reuniao: l.data_reuniao,
            semana: l.semana,
            tipo: l.tipo,
            nome: l.nome,
            estudante: estudanteNome,
            estudante_id: l.estudante_id,
            ajudante: ajudanteNome,
            sala: l.sala,
          };
        });

      const puladas = linhasS140.length - paraInserir.length;

      if (paraInserir.length > 0) {
        const { error } = await supabase.from("designacoes").insert(paraInserir);
        if (error) throw error;
      }

      setMensagem(
        `${paraInserir.length} designações importadas.` +
          (puladas > 0 ? ` ${puladas} já existiam e foram ignoradas.` : "")
      );
      setLinhasS140(null);
    } catch (err) {
      setMensagem(
        `Erro ao gravar importação: ${err instanceof Error ? err.message : String(err)}`
      );
    } finally {
      setImportando(false);
    }
  }

  async function handleUploadPdf(e: React.ChangeEvent<HTMLInputElement>) {
    const arquivo = e.target.files?.[0];
    if (!arquivo) return;
    await processarEEnviarPdf(arquivo);
    if (inputPdf.current) inputPdf.current.value = "";
  }

  async function processarEEnviarPdf(
    arquivo: File,
    estudantesParaSugestao: EstudanteBasico[] = estudantes
  ) {
    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    const caminho = `${user.id}/${Date.now()}_${arquivo.name}`;
    const { error: erroUpload } = await supabase.storage
      .from("pdfs")
      .upload(caminho, arquivo);

    if (erroUpload) {
      setMensagem(`Erro ao enviar PDF: ${erroUpload.message}`);
      return;
    }

    // Extração de texto é "melhor esforço": se o PDF for uma imagem
    // escaneada (sem camada de texto) ou o parsing falhar por qualquer
    // motivo, o upload já foi feito — só não teremos sugestão
    // automática, e o usuário revisa manualmente.
    let texto = "";
    let estudanteIdSugerido: string | null = null;
    let tipoSugerido: string | null = null;
    setExtraindo(true);
    try {
      const resultado = await processarPdf(arquivo, estudantesParaSugestao);
      texto = resultado.texto;
      estudanteIdSugerido = resultado.estudanteIdSugerido;
      tipoSugerido = resultado.tipoSugerido;
    } catch (err) {
      console.warn("Falha ao extrair texto do PDF:", err);
    } finally {
      setExtraindo(false);
    }

    await supabase.from("pdfs_recebidos").insert({
      user_id: user.id,
      nome_arquivo: arquivo.name,
      caminho_arquivo: caminho,
      texto_extraido: texto || null,
      estudante_id: estudanteIdSugerido,
      tipo_detectado: tipoSugerido ?? "",
      processado: false,
    });

    setMensagem(
      estudanteIdSugerido || tipoSugerido
        ? "PDF enviado. Confira a sugestão abaixo e confirme."
        : "PDF enviado. Não foi possível sugerir estudante/tipo automaticamente — preencha manualmente abaixo."
    );
    carregar();
  }

  async function confirmarRevisao(
    pdf: PdfRecebido,
    estudante_id: string,
    tipo_detectado: string
  ) {
    const estudante = estudantes.find((e) => e.id === estudante_id);
    await supabase
      .from("pdfs_recebidos")
      .update({
        estudante_id: estudante_id || null,
        estudante: estudante?.nome ?? "",
        tipo_detectado,
        processado: true,
      })
      .eq("id", pdf.id);
    carregar();
  }

  return (
    <div>
      <PageHeader title="PDFs e Importação" />

      <div className="space-y-6 p-4 md:p-6">
        <div className="grid gap-4 sm:grid-cols-2">
          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <h2 className="mb-1 text-sm font-semibold text-slate-900">
              Importar programação (S-140)
            </h2>
            <p className="mb-3 text-xs text-slate-500">
              Planilha da programação semanal, no formato exportado pelo
              "Central". Você confere e confirma antes de gravar.
            </p>
            <button
              type="button"
              onClick={() => inputExcel.current?.click()}
              disabled={importando}
              className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {importando ? "Processando..." : "Selecionar planilha (.xlsx)"}
            </button>
            <input
              ref={inputExcel}
              type="file"
              accept=".xlsx,.xls"
              onChange={handleImportarExcel}
              disabled={importando}
              className="hidden"
            />
          </div>

          <div className="rounded-xl border border-slate-200 bg-white p-5">
            <h2 className="mb-1 text-sm font-semibold text-slate-900">
              Enviar PDF de designação
            </h2>
            <p className="mb-3 text-xs text-slate-500">
              Armazenado no seu Supabase Storage, associado à sua conta.
            </p>
            <button
              type="button"
              onClick={() => inputPdf.current?.click()}
              disabled={extraindo}
              className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-50"
            >
              {extraindo ? "Extraindo..." : "Selecionar PDF"}
            </button>
            <input
              ref={inputPdf}
              type="file"
              accept="application/pdf"
              onChange={handleUploadPdf}
              disabled={extraindo}
              className="hidden"
            />
          </div>
        </div>

        {mensagem && (
          <p className="rounded-lg bg-slate-100 px-3 py-2 text-sm text-slate-700">
            {mensagem}
          </p>
        )}

        {linhasS140 && (
          <RevisaoS140
            linhas={linhasS140}
            estudantes={estudantes}
            importando={importando}
            onAtualizarLinha={atualizarLinhaS140}
            onConfirmar={confirmarImportacaoS140}
            onCancelar={() => setLinhasS140(null)}
          />
        )}

        <div>
          <h2 className="mb-2 text-sm font-semibold text-slate-500">
            PDFs recebidos
          </h2>
          {carregando ? (
            <p className="text-sm text-slate-500">Carregando...</p>
          ) : lista.length === 0 ? (
            <p className="text-sm text-slate-500">Nenhum PDF ainda.</p>
          ) : (
            <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
              {lista.map((p) => (
                <div
                  key={p.id}
                  className="border-b border-slate-100 px-4 py-3 last:border-0"
                >
                  <div className="flex items-center justify-between">
                    <div>
                      <p className="text-sm font-medium text-slate-900">
                        {p.nome_arquivo}
                      </p>
                      <p className="text-xs text-slate-500">
                        {new Date(p.recebido_em).toLocaleString("pt-BR")}
                      </p>
                    </div>
                    <span
                      className={`rounded-full px-2 py-0.5 text-xs ${
                        p.processado
                          ? "bg-emerald-100 text-emerald-700"
                          : "bg-amber-100 text-amber-700"
                      }`}
                    >
                      {p.processado ? "Processado" : "Pendente"}
                    </span>
                  </div>

                  {!p.processado && (
                    <RevisaoPdf
                      pdf={p}
                      estudantes={estudantes}
                      onConfirmar={confirmarRevisao}
                    />
                  )}
                </div>
              ))}
            </div>
          )}
        </div>
      </div>
    </div>
  );
}

function RevisaoPdf({
  pdf,
  estudantes,
  onConfirmar,
}: {
  pdf: PdfRecebido;
  estudantes: EstudanteBasico[];
  onConfirmar: (
    pdf: PdfRecebido,
    estudante_id: string,
    tipo_detectado: string
  ) => void;
}) {
  const [estudanteId, setEstudanteId] = useState(pdf.estudante_id ?? "");
  const [tipo, setTipo] = useState(pdf.tipo_detectado ?? "");
  const [mostrarTexto, setMostrarTexto] = useState(false);

  return (
    <div className="mt-3 space-y-2 rounded-lg bg-slate-50 p-3">
      <div className="grid gap-2 sm:grid-cols-2">
        <div>
          <label className="mb-1 block text-xs font-medium text-slate-600">
            Estudante {pdf.estudante_id && "(sugerido)"}
          </label>
          <select
            value={estudanteId}
            onChange={(e) => setEstudanteId(e.target.value)}
            className="w-full rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-sm text-slate-900"
          >
            <option value="">Selecione...</option>
            {estudantes.map((e) => (
              <option key={e.id} value={e.id}>
                {e.nome}
              </option>
            ))}
          </select>
        </div>
        <div>
          <label className="mb-1 block text-xs font-medium text-slate-600">
            Tipo {pdf.tipo_detectado && "(sugerido)"}
          </label>
          <select
            value={tipo}
            onChange={(e) => setTipo(e.target.value)}
            className="w-full rounded-lg border border-slate-300 bg-white px-2 py-1.5 text-sm text-slate-900"
          >
            <option value="">Selecione...</option>
            {TIPOS_DESIGNACAO.map((t) => (
              <option key={t} value={t}>
                {t}
              </option>
            ))}
          </select>
        </div>
      </div>

      {pdf.texto_extraido && (
        <div>
          <button
            type="button"
            onClick={() => setMostrarTexto((v) => !v)}
            className="text-xs text-indigo-600 hover:underline"
          >
            {mostrarTexto ? "Ocultar" : "Ver"} texto extraído
          </button>
          {mostrarTexto && (
            <pre className="mt-1 max-h-40 overflow-auto whitespace-pre-wrap rounded border border-slate-200 bg-white p-2 text-xs text-slate-600">
              {pdf.texto_extraido}
            </pre>
          )}
        </div>
      )}

      <button
        type="button"
        disabled={!estudanteId || !tipo}
        onClick={() => onConfirmar(pdf, estudanteId, tipo)}
        className="rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-50"
      >
        Confirmar
      </button>
    </div>
  );
}

function RevisaoS140({
  linhas,
  estudantes,
  importando,
  onAtualizarLinha,
  onConfirmar,
  onCancelar,
}: {
  linhas: LinhaS140Revisada[];
  estudantes: EstudanteBasico[];
  importando: boolean;
  onAtualizarLinha: (
    indice: number,
    campo: "estudante_id" | "ajudante_id",
    valor: string
  ) => void;
  onConfirmar: () => void;
  onCancelar: () => void;
}) {
  const semVinculo = linhas.filter((l) => l.estudante && !l.estudante_id).length;

  // agrupa por data para exibir com um cabeçalho de semana
  const porData = new Map<string, { indices: number[]; semana: string }>();
  linhas.forEach((l, i) => {
    const grupo = porData.get(l.data_reuniao) ?? { indices: [], semana: l.semana };
    grupo.indices.push(i);
    porData.set(l.data_reuniao, grupo);
  });

  return (
    <div className="rounded-xl border border-slate-200 bg-white">
      <div className="flex items-center justify-between border-b border-slate-200 px-4 py-3">
        <div>
          <h2 className="text-sm font-semibold text-slate-900">
            Revisar importação — {linhas.length} designações encontradas
          </h2>
          {semVinculo > 0 && (
            <p className="text-xs text-amber-600">
              {semVinculo} sem estudante cadastrado correspondente — selecione
              manualmente abaixo (ou deixe em branco para vincular depois em
              "Designações").
            </p>
          )}
        </div>
        <div className="flex gap-2">
          <button
            type="button"
            onClick={onCancelar}
            disabled={importando}
            className="rounded-lg px-3 py-1.5 text-xs text-slate-600 hover:bg-slate-100"
          >
            Cancelar
          </button>
          <button
            type="button"
            onClick={onConfirmar}
            disabled={importando}
            className="rounded-lg bg-indigo-600 px-3 py-1.5 text-xs font-medium text-white hover:bg-indigo-700 disabled:cursor-not-allowed disabled:opacity-50"
          >
            {importando ? "Importando..." : "Confirmar importação"}
          </button>
        </div>
      </div>

      <div className="max-h-[32rem] divide-y divide-slate-100 overflow-y-auto">
        {[...porData.entries()].map(([data, grupo]) => (
          <div key={data}>
            <div className="bg-slate-50 px-4 py-1.5 text-xs font-medium text-slate-500">
              {new Date(data + "T00:00:00").toLocaleDateString("pt-BR", {
                weekday: "short",
                day: "2-digit",
                month: "2-digit",
              })}{" "}
              — {grupo.semana}
            </div>
            {grupo.indices.map((i) => {
              const l = linhas[i];
              return (
                <div key={i} className="flex flex-wrap items-center gap-2 px-4 py-2 text-sm">
                  <span className="w-40 shrink-0 text-slate-700">{l.nome}</span>
                  {l.sala && (
                    <span className="shrink-0 rounded-full bg-slate-100 px-2 py-0.5 text-xs text-slate-500">
                      {l.sala}
                    </span>
                  )}

                  <SeletorEstudante
                    valor={l.estudante_id}
                    nomeOriginal={l.estudante}
                    estudantes={estudantes}
                    onChange={(v) => onAtualizarLinha(i, "estudante_id", v)}
                  />

                  {l.ajudante && (
                    <>
                      <span className="text-xs text-slate-400">+</span>
                      <SeletorEstudante
                        valor={l.ajudante_id}
                        nomeOriginal={l.ajudante}
                        estudantes={estudantes}
                        onChange={(v) => onAtualizarLinha(i, "ajudante_id", v)}
                      />
                    </>
                  )}
                </div>
              );
            })}
          </div>
        ))}
      </div>
    </div>
  );
}

function SeletorEstudante({
  valor,
  nomeOriginal,
  estudantes,
  onChange,
}: {
  valor: string | null;
  nomeOriginal: string;
  estudantes: EstudanteBasico[];
  onChange: (v: string) => void;
}) {
  return (
    <select
      value={valor ?? ""}
      onChange={(e) => onChange(e.target.value)}
      className={`min-w-0 flex-1 rounded-lg border px-2 py-1 text-sm text-slate-900 ${
        valor ? "border-slate-300 bg-white" : "border-amber-300 bg-amber-50"
      }`}
    >
      <option value="">
        {nomeOriginal ? `"${nomeOriginal}" — sem vínculo` : "Selecione..."}
      </option>
      {estudantes.map((e) => (
        <option key={e.id} value={e.id}>
          {e.nome}
        </option>
      ))}
    </select>
  );
}
