import { useEffect, useRef, useState } from "react";
import { supabase } from "../lib/supabase";
import type { Estudante } from "../lib/database.types";
import PageHeader from "../components/PageHeader";
import {
  importarEstudantesExcel,
  exportarEstudantesExcel,
} from "../services/estudantesExcel";

function normalizar(texto: string) {
  return texto
    .toLowerCase()
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "");
}

const RESPONSABILIDADES = [
  "Publicador",
  "Estudante",
  "Batizado",
  "Servo ministerial",
  "Ancião",
];

const QUALIFICACOES: { campo: keyof Estudante; label: string }[] = [
  { campo: "qualificado_leitura", label: "Leitura" },
  { campo: "qualificado_ajudante", label: "Ajudante" },
  { campo: "qualificado_iniciando", label: "Iniciando conversas" },
  { campo: "qualificado_cultivando", label: "Cultivando o interesse" },
  { campo: "qualificado_explicando", label: "Explicando" },
  { campo: "qualificado_discipulos", label: "Fazendo discípulos" },
  { campo: "qualificado_discurso", label: "Discurso" },
];

export default function Estudantes() {
  const [lista, setLista] = useState<Estudante[]>([]);
  const [busca, setBusca] = useState("");
  const [carregando, setCarregando] = useState(true);
  const [editando, setEditando] = useState<Partial<Estudante> | null>(null);
  const [importando, setImportando] = useState(false);
  const [mensagem, setMensagem] = useState<string | null>(null);
  const inputExcel = useRef<HTMLInputElement>(null);

  async function carregar() {
    setCarregando(true);
    const { data } = await supabase
      .from("estudantes")
      .select("*")
      .order("nome", { ascending: true });
    setLista(data ?? []);
    setCarregando(false);
  }

  useEffect(() => {
    carregar();
  }, []);

  async function salvar(e: React.FormEvent) {
    e.preventDefault();
    if (!editando) return;

    const {
      data: { user },
    } = await supabase.auth.getUser();
    if (!user) return;

    const payload = {
      ...editando,
      nome_pesquisa: normalizar(editando.nome ?? ""),
      user_id: user.id,
    };

    if (editando.id) {
      await supabase.from("estudantes").update(payload).eq("id", editando.id);
    } else {
      await supabase.from("estudantes").insert(payload);
    }

    setEditando(null);
    carregar();
  }

  async function remover(id: string) {
    if (!confirm("Remover este estudante?")) return;
    await supabase.from("estudantes").delete().eq("id", id);
    carregar();
  }

  async function handleImportarExcel(e: React.ChangeEvent<HTMLInputElement>) {
    const arquivo = e.target.files?.[0];
    if (!arquivo) return;
    setImportando(true);
    setMensagem(null);
    try {
      const importados = await importarEstudantesExcel(arquivo);
      const {
        data: { user },
      } = await supabase.auth.getUser();
      if (!user) throw new Error("Sessão expirada");

      // upsert por nome: se já existe um estudante com esse nome
      // (normalizado), atualiza; senão, cria. Evita duplicar cadastro
      // ao reimportar a mesma planilha depois de editada.
      const existentesPorNome = new Map(
        lista.map((e) => [normalizar(e.nome), e])
      );

      let criados = 0;
      let atualizados = 0;
      for (const imp of importados) {
        const existente = existentesPorNome.get(normalizar(imp.nome));
        const payload = {
          ...imp,
          nome_pesquisa: normalizar(imp.nome),
          user_id: user.id,
        };
        if (existente) {
          await supabase.from("estudantes").update(payload).eq("id", existente.id);
          atualizados++;
        } else {
          await supabase.from("estudantes").insert(payload);
          criados++;
        }
      }

      setMensagem(
        `Importação concluída: ${criados} estudante(s) novo(s), ${atualizados} atualizado(s).`
      );
      carregar();
    } catch (err) {
      setMensagem(err instanceof Error ? err.message : "Erro ao importar planilha.");
    } finally {
      setImportando(false);
      if (inputExcel.current) inputExcel.current.value = "";
    }
  }

  async function handleExportarExcel() {
    const blob = await exportarEstudantesExcel(lista);
    const url = URL.createObjectURL(blob);
    const a = document.createElement("a");
    a.href = url;
    a.download = "estudantes.xlsx";
    a.click();
    URL.revokeObjectURL(url);
  }

  const filtrados = lista.filter((e) =>
    normalizar(e.nome).includes(normalizar(busca))
  );

  return (
    <div>
      <PageHeader
        title="Estudantes"
        action={
          <div className="flex items-center gap-2">
            <button
              onClick={() => inputExcel.current?.click()}
              disabled={importando}
              className="rounded-lg border border-slate-300 px-3 py-1.5 text-sm font-medium text-slate-700 hover:bg-slate-50 disabled:opacity-50"
            >
              {importando ? "Importando..." : "Importar Excel"}
            </button>
            <button
              onClick={handleExportarExcel}
              className="rounded-lg border border-slate-300 px-3 py-1.5 text-sm font-medium text-slate-700 hover:bg-slate-50"
            >
              Exportar Excel
            </button>
            <input
              ref={inputExcel}
              type="file"
              accept=".xlsx,.xls"
              onChange={handleImportarExcel}
              className="hidden"
            />
            <button
              onClick={() => setEditando({})}
              className="rounded-lg bg-indigo-600 px-3 py-1.5 text-sm font-medium text-white hover:bg-indigo-700"
            >
              + Novo
            </button>
          </div>
        }
      />

      <div className="p-4 md:p-6">
        {mensagem && (
          <div className="mb-4 rounded-lg bg-indigo-50 px-3 py-2 text-sm text-indigo-700">
            {mensagem}
          </div>
        )}

        <input
          placeholder="Buscar por nome..."
          value={busca}
          onChange={(e) => setBusca(e.target.value)}
          className="mb-4 w-full max-w-sm rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none"
        />

        {carregando ? (
          <p className="text-sm text-slate-500">Carregando...</p>
        ) : filtrados.length === 0 ? (
          <p className="text-sm text-slate-500">Nenhum estudante encontrado.</p>
        ) : (
          <div className="overflow-hidden rounded-xl border border-slate-200 bg-white">
            <table className="w-full text-left text-sm">
              <thead className="border-b border-slate-200 bg-slate-50 text-slate-500">
                <tr>
                  <th className="px-4 py-2 font-medium">Nome</th>
                  <th className="hidden px-4 py-2 font-medium sm:table-cell">Telefone</th>
                  <th className="hidden px-4 py-2 font-medium md:table-cell">Responsabilidade</th>
                  <th className="hidden px-4 py-2 font-medium md:table-cell">Status</th>
                  <th className="px-4 py-2" />
                </tr>
              </thead>
              <tbody>
                {filtrados.map((e) => (
                  <tr key={e.id} className="border-b border-slate-100 last:border-0">
                    <td className="px-4 py-2">
                      {e.nome}
                      {e.pioneiro && (
                        <span className="ml-2 rounded-full bg-indigo-100 px-2 py-0.5 text-xs text-indigo-700">
                          Pioneiro
                        </span>
                      )}
                    </td>
                    <td className="hidden px-4 py-2 text-slate-500 sm:table-cell">
                      {e.telefone || "—"}
                    </td>
                    <td className="hidden px-4 py-2 text-slate-500 md:table-cell">
                      {e.responsabilidade || "—"}
                    </td>
                    <td className="hidden px-4 py-2 md:table-cell">
                      <span
                        className={`rounded-full px-2 py-0.5 text-xs ${
                          e.ativo
                            ? "bg-emerald-100 text-emerald-700"
                            : "bg-slate-100 text-slate-500"
                        }`}
                      >
                        {e.ativo ? "Ativo" : "Inativo"}
                      </span>
                    </td>
                    <td className="px-4 py-2 text-right">
                      <button
                        onClick={() => setEditando(e)}
                        className="mr-2 text-indigo-600 hover:underline"
                      >
                        Editar
                      </button>
                      <button
                        onClick={() => remover(e.id)}
                        className="text-red-600 hover:underline"
                      >
                        Remover
                      </button>
                    </td>
                  </tr>
                ))}
              </tbody>
            </table>
          </div>
        )}
      </div>

      {editando && (
        <div className="fixed inset-0 z-20 flex items-end justify-center overflow-y-auto bg-black/30 p-0 sm:items-center sm:p-4">
          <form
            onSubmit={salvar}
            className="w-full max-w-md space-y-4 rounded-t-2xl bg-white p-6 sm:my-8 sm:rounded-2xl"
          >
            <h2 className="text-lg font-semibold text-slate-900">
              {editando.id ? "Editar estudante" : "Novo estudante"}
            </h2>

            <Campo
              label="Nome"
              value={editando.nome ?? ""}
              onChange={(v) => setEditando({ ...editando, nome: v })}
              required
            />
            <Campo
              label="Telefone (WhatsApp)"
              value={editando.telefone ?? ""}
              onChange={(v) => setEditando({ ...editando, telefone: v })}
              placeholder="+55 11 91234-5678"
            />
            <Campo
              label="E-mail"
              value={editando.email ?? ""}
              onChange={(v) => setEditando({ ...editando, email: v })}
            />

            <div className="grid grid-cols-2 gap-3">
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">
                  Responsabilidade
                </label>
                <select
                  value={editando.responsabilidade ?? ""}
                  onChange={(e) =>
                    setEditando({ ...editando, responsabilidade: e.target.value })
                  }
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none"
                >
                  <option value="">—</option>
                  {RESPONSABILIDADES.map((r) => (
                    <option key={r} value={r}>
                      {r}
                    </option>
                  ))}
                </select>
              </div>
              <div>
                <label className="mb-1 block text-sm font-medium text-slate-700">
                  Gênero
                </label>
                <select
                  value={editando.genero ?? ""}
                  onChange={(e) =>
                    setEditando({
                      ...editando,
                      genero: e.target.value as "" | "M" | "F",
                    })
                  }
                  className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none"
                >
                  <option value="">—</option>
                  <option value="M">Masculino</option>
                  <option value="F">Feminino</option>
                </select>
              </div>
            </div>

            <div className="grid grid-cols-2 gap-3">
              <Campo
                label="Nascimento"
                type="date"
                value={editando.nascimento ?? ""}
                onChange={(v) => setEditando({ ...editando, nascimento: v || null })}
              />
              <Campo
                label="Batismo"
                type="date"
                value={editando.batismo ?? ""}
                onChange={(v) => setEditando({ ...editando, batismo: v || null })}
              />
            </div>

            <label className="flex items-center gap-2 text-sm text-slate-700">
              <input
                type="checkbox"
                checked={editando.pioneiro ?? false}
                onChange={(e) =>
                  setEditando({ ...editando, pioneiro: e.target.checked })
                }
              />
              Pioneiro
            </label>

            <div>
              <p className="mb-2 text-sm font-medium text-slate-700">
                Qualificado para
              </p>
              <div className="grid grid-cols-2 gap-2">
                {QUALIFICACOES.map(({ campo, label }) => (
                  <label
                    key={campo}
                    className="flex items-center gap-2 text-sm text-slate-700"
                  >
                    <input
                      type="checkbox"
                      checked={Boolean(editando[campo])}
                      onChange={(e) =>
                        setEditando({ ...editando, [campo]: e.target.checked })
                      }
                    />
                    {label}
                  </label>
                ))}
              </div>
            </div>

            <div>
              <label className="mb-1 block text-sm font-medium text-slate-700">
                Observações
              </label>
              <textarea
                value={editando.observacoes ?? ""}
                onChange={(e) =>
                  setEditando({ ...editando, observacoes: e.target.value })
                }
                rows={2}
                className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none"
              />
            </div>

            <label className="flex items-center gap-2 text-sm text-slate-700">
              <input
                type="checkbox"
                checked={editando.ativo ?? true}
                onChange={(e) =>
                  setEditando({ ...editando, ativo: e.target.checked })
                }
              />
              Ativo
            </label>

            <label className="flex items-center gap-2 text-sm text-slate-700">
              <input
                type="checkbox"
                checked={editando.recebe_whatsapp ?? true}
                onChange={(e) =>
                  setEditando({ ...editando, recebe_whatsapp: e.target.checked })
                }
              />
              Recebe designações por WhatsApp
            </label>

            <div className="flex justify-end gap-2 pt-2">
              <button
                type="button"
                onClick={() => setEditando(null)}
                className="rounded-lg px-4 py-2 text-sm text-slate-600 hover:bg-slate-100"
              >
                Cancelar
              </button>
              <button
                type="submit"
                className="rounded-lg bg-indigo-600 px-4 py-2 text-sm font-medium text-white hover:bg-indigo-700"
              >
                Salvar
              </button>
            </div>
          </form>
        </div>
      )}
    </div>
  );
}

function Campo({
  label,
  value,
  onChange,
  required,
  placeholder,
  type = "text",
}: {
  label: string;
  value: string;
  onChange: (v: string) => void;
  required?: boolean;
  placeholder?: string;
  type?: string;
}) {
  return (
    <div>
      <label className="mb-1 block text-sm font-medium text-slate-700">
        {label}
      </label>
      <input
        type={type}
        value={value}
        required={required}
        placeholder={placeholder}
        onChange={(e) => onChange(e.target.value)}
        className="w-full rounded-lg border border-slate-300 bg-white px-3 py-2 text-sm text-slate-900 focus:border-indigo-500 focus:outline-none"
      />
    </div>
  );
}
