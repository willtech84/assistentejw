// Import/export de Estudantes em Excel, no formato real usado pela
// congregação (colunas: Nome, Leitura, Ajudante, Iniciando, Cultivando
// o interesse, Explicando, Discípulos, Discurso, Frequência,
// Responsabilidade, Pioneiro, Gênero, Nascimento, Batismo, Celular,
// Email, Observações — como em Estudantes.xlsx).
//
// A leitura é por NOME da coluna, não por posição — assim funciona
// mesmo se a ordem das colunas mudar ou colunas forem adicionadas.
// A linha "Total" (soma no rodapé da planilha original) é ignorada
// automaticamente.
//
// "Frequência" não é importada: não há um significado claro e
// verificável dessa coluna na planilha de origem, e preencher um
// campo com dado adivinhado seria pior do que não ter o campo.

import type { Estudante } from "../lib/database.types";
import { excelDataParaISOOuNull } from "./excelImport";

export interface EstudanteImportado {
  nome: string;
  qualificado_leitura: boolean;
  qualificado_ajudante: boolean;
  qualificado_iniciando: boolean;
  qualificado_cultivando: boolean;
  qualificado_explicando: boolean;
  qualificado_discipulos: boolean;
  qualificado_discurso: boolean;
  responsabilidade: string;
  pioneiro: boolean;
  genero: "" | "M" | "F";
  nascimento: string | null;
  batismo: string | null;
  telefone: string;
  email: string;
  observacoes: string;
}

const COLUNAS = [
  "Nome",
  "Leitura",
  "Ajudante",
  "Iniciando",
  "Cultivando o interesse",
  "Explicando",
  "Discípulos",
  "Discurso",
  "Freqüência",
  "Responsabilidade",
  "Pioneiro",
  "Gênero",
  "Nascimento",
  "Batismo",
  "Celular",
  "Email",
  "Observações",
] as const;

function paraBooleano(valor: unknown): boolean {
  return valor === 1 || valor === "1" || valor === true;
}

function paraTexto(valor: unknown): string {
  return valor === null || valor === undefined ? "" : String(valor).trim();
}

export async function importarEstudantesExcel(
  arquivo: File
): Promise<EstudanteImportado[]> {
  const XLSX = await import("xlsx");
  const buffer = await arquivo.arrayBuffer();
  const planilha = XLSX.read(buffer, { type: "array" });

  // procura, nas primeiras linhas de cada aba, aquela que tem "Nome"
  // como primeira célula — é a linha de cabeçalho de verdade (a
  // planilha original tem um título e linhas em branco antes dela).
  for (const nomeAba of planilha.SheetNames) {
    const aba = planilha.Sheets[nomeAba];
    const matriz = XLSX.utils.sheet_to_json<unknown[]>(aba, {
      header: 1,
      defval: "",
    });

    const indiceCabecalho = matriz.findIndex(
      (linha) => String(linha[0]).trim().toLowerCase() === "nome"
    );
    if (indiceCabecalho === -1) continue;

    const cabecalho = matriz[indiceCabecalho].map((c) => String(c).trim());
    const indice = (coluna: string) => cabecalho.indexOf(coluna);

    const linhasDados = matriz.slice(indiceCabecalho + 1);

    return linhasDados
      .filter((linha) => {
        const nome = paraTexto(linha[indice("Nome")]);
        // ignora linhas em branco e a linha "Total" do rodapé
        return nome && nome.toLowerCase() !== "total";
      })
      .map((linha) => ({
        nome: paraTexto(linha[indice("Nome")]),
        qualificado_leitura: paraBooleano(linha[indice("Leitura")]),
        qualificado_ajudante: paraBooleano(linha[indice("Ajudante")]),
        qualificado_iniciando: paraBooleano(linha[indice("Iniciando")]),
        qualificado_cultivando: paraBooleano(
          linha[indice("Cultivando o interesse")]
        ),
        qualificado_explicando: paraBooleano(linha[indice("Explicando")]),
        qualificado_discipulos: paraBooleano(linha[indice("Discípulos")]),
        qualificado_discurso: paraBooleano(linha[indice("Discurso")]),
        responsabilidade: paraTexto(linha[indice("Responsabilidade")]),
        pioneiro: paraBooleano(linha[indice("Pioneiro")]),
        genero: (paraTexto(linha[indice("Gênero")]).toUpperCase() === "M"
          ? "M"
          : paraTexto(linha[indice("Gênero")]).toUpperCase() === "F"
            ? "F"
            : "") as "" | "M" | "F",
        nascimento: excelDataParaISOOuNull(linha[indice("Nascimento")], XLSX.SSF),
        batismo: excelDataParaISOOuNull(linha[indice("Batismo")], XLSX.SSF),
        telefone: paraTexto(linha[indice("Celular")]),
        email: paraTexto(linha[indice("Email")]),
        observacoes: paraTexto(linha[indice("Observações")]),
      }));
  }

  throw new Error(
    'Não encontrei uma coluna "Nome" em nenhuma aba da planilha. Confirme se o arquivo tem esse cabeçalho.'
  );
}

function paraISOparaDDMMAAAA(iso: string | null): string {
  if (!iso) return "";
  const [ano, mes, dia] = iso.split("-");
  return `${dia}/${mes}/${ano}`;
}

export async function exportarEstudantesExcel(
  estudantes: Estudante[]
): Promise<Blob> {
  const XLSX = await import("xlsx");

  const linhas = estudantes.map((e) => ({
    Nome: e.nome,
    Leitura: e.qualificado_leitura ? 1 : "",
    Ajudante: e.qualificado_ajudante ? 1 : "",
    Iniciando: e.qualificado_iniciando ? 1 : "",
    "Cultivando o interesse": e.qualificado_cultivando ? 1 : "",
    Explicando: e.qualificado_explicando ? 1 : "",
    Discípulos: e.qualificado_discipulos ? 1 : "",
    Discurso: e.qualificado_discurso ? 1 : "",
    Responsabilidade: e.responsabilidade,
    Pioneiro: e.pioneiro ? 1 : "",
    Gênero: e.genero,
    Nascimento: paraISOparaDDMMAAAA(e.nascimento),
    Batismo: paraISOparaDDMMAAAA(e.batismo),
    Celular: e.telefone,
    Email: e.email,
    Observações: e.observacoes,
  }));

  const planilha = XLSX.utils.book_new();
  const aba = XLSX.utils.json_to_sheet(linhas, { header: [...COLUNAS] as string[] });
  XLSX.utils.book_append_sheet(planilha, aba, "Estudantes");

  const arrayBuffer = XLSX.write(planilha, { type: "array", bookType: "xlsx" });
  return new Blob([arrayBuffer], {
    type: "application/vnd.openxmlformats-officedocument.spreadsheetml.sheet",
  });
}
