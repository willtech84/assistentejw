// Preenche o formulário S-89 (template em public/templates/s89-template.pdf,
// um AcroForm oficial) com os dados de uma designação, no navegador,
// via pdf-lib. Confirmado campo a campo contra um PDF real preenchido
// pela congregação (ver notas em supabase/migrations e no histórico do
// projeto) — os nomes de campo abaixo não são um palpite.

import type { PDFCheckBox } from "pdf-lib";
import type { Designacao } from "../lib/database.types";

const CAMINHO_TEMPLATE = "/templates/s89-template.pdf";

const CAMPO_NOME = "900_1_Text_SanSerif";
const CAMPO_AJUDANTE = "900_2_Text_SanSerif";
const CAMPO_DATA = "900_3_Text_SanSerif";
const CAMPO_PARTE = "900_4_Text_SanSerif";

// ordem confirmada no PDF: Salão principal / Sala B / Sala C
const CAMPO_SALA: Record<string, string> = {
  "Salão principal": "900_5_CheckBox",
  Principal: "900_5_CheckBox", // valor default antigo do schema, antes desta feature
  "Sala B": "900_6_CheckBox",
  "Sala C": "900_7_CheckBox",
};

function formatarDataBR(iso: string): string {
  const [ano, mes, dia] = iso.split("-");
  if (!ano || !mes || !dia) return iso;
  return `${dia}/${mes}/${ano}`;
}

export async function gerarS89(designacao: Designacao): Promise<Blob> {
  const { PDFDocument } = await import("pdf-lib");
  const resposta = await fetch(CAMINHO_TEMPLATE);
  if (!resposta.ok) {
    throw new Error(
      "Não consegui carregar o modelo do S-89. Verifique se o arquivo public/templates/s89-template.pdf está no build."
    );
  }
  const bytesTemplate = await resposta.arrayBuffer();
  const documento = await PDFDocument.load(bytesTemplate);
  const formulario = documento.getForm();

  formulario.getTextField(CAMPO_NOME).setText(designacao.estudante || "");
  formulario.getTextField(CAMPO_AJUDANTE).setText(designacao.ajudante || "");
  formulario.getTextField(CAMPO_DATA).setText(formatarDataBR(designacao.data_reuniao));
  formulario.getTextField(CAMPO_PARTE).setText(designacao.nome || "");

  const nomeCampoSala = CAMPO_SALA[designacao.sala];
  if (nomeCampoSala) {
    const checkbox = formulario.getCheckBox(nomeCampoSala) as PDFCheckBox;
    checkbox.check();
  }

  const bytesGerados = await documento.save();
  return new Blob([bytesGerados.buffer as ArrayBuffer], { type: "application/pdf" });
}

export function nomeArquivoS89(designacao: Designacao): string {
  const nomeArquivoSeguro = (designacao.estudante || "estudante")
    .normalize("NFD")
    .replace(/[\u0300-\u036f]/g, "")
    .replace(/[^\w\s-]/g, "")
    .trim()
    .replace(/\s+/g, "_");
  return `S89_${designacao.data_reuniao}_${nomeArquivoSeguro}.pdf`;
}

/**
 * Gera o S-89 e tenta abrir o menu nativo de compartilhamento (que no
 * Android/iOS inclui o WhatsApp direto, já com o arquivo anexado) —
 * é o mesmo Web Share API usado do lado de "receber" no service worker
 * (src/sw.ts), aqui do lado de "enviar". Quando o navegador não suporta
 * compartilhar arquivos (a maioria dos navegadores desktop), cai para
 * um download comum.
 */
export async function compartilharOuBaixarS89(
  designacao: Designacao
): Promise<"compartilhado" | "baixado"> {
  const blob = await gerarS89(designacao);
  const arquivo = new File([blob], nomeArquivoS89(designacao), {
    type: "application/pdf",
  });

  if (
    typeof navigator.share === "function" &&
    typeof navigator.canShare === "function" &&
    navigator.canShare({ files: [arquivo] })
  ) {
    try {
      await navigator.share({
        files: [arquivo],
        title: "Designação — " + designacao.estudante,
      });
      return "compartilhado";
    } catch (err) {
      // usuário cancelou o menu de compartilhamento — não é erro
      if (err instanceof Error && err.name === "AbortError") {
        return "compartilhado";
      }
      // qualquer outro erro: cai para download normal abaixo
    }
  }

  const url = URL.createObjectURL(blob);
  const a = document.createElement("a");
  a.href = url;
  a.download = arquivo.name;
  a.click();
  URL.revokeObjectURL(url);
  return "baixado";
}
