// Parser da planilha S-140 (programação semanal da Vida e Ministério),
// no layout real exportado pelo "Central" (confirmado com o arquivo de
// exemplo S140_202608.xlsx). Diferente de excelImport.ts (formato
// simples genérico, uma linha = uma designação), este é um parser
// dedicado a um template com layout fixo por células.
//
// Estrutura do template (colunas B..L, 1 aba por quinzena/mês, 1 bloco
// de ~29 linhas por semana):
//   col B: "DD/MM/AAAA | TEMA" marca o início do bloco da semana
//   col B/D com rótulo em col J ("Presidente:", "Dirigente da sala B:",
//     "Dirigente da sala C:", "Oração:", "Dirigente/Leitor:") + valor
//     em col K — designação única (não dividida por sala)
//   col D = título/número da parte; rótulo em col F ("Estudante:",
//     "Estudante/Ajudante:") quando a parte tem estudante; valores
//     divididos em 3 colunas por sala: G=Sala C, I=Sala B, K=Salão
//     principal
//   partes sem rótulo (pontos 1/2 de Tesouros, discursos de Nossa
//     Vida Cristã) têm o nome direto na col K (sala única)
//   linhas placeholder de semanas com menos partes têm "[Tema]" no
//     título e "Nome"/"Nome/Nome" como valor — são ignoradas
//
// O que sai daqui é sempre um valor SUGERIDO — não grava nada sozinho.
// A tela de Designações mostra a lista para revisão antes de importar
// de fato (mesmo espírito do que já fizemos na extração de PDF).

export interface DesignacaoS140 {
  data_reuniao: string; // YYYY-MM-DD
  semana: string; // tema da semana, ex: "JEREMIAS 22-23"
  tipo: string;
  nome: string; // "3. Leitura da Bíblia" — vai direto no S-89 depois
  estudante: string;
  ajudante: string;
  sala: string; // "Sala B" | "Sala C" | "Salão principal" | ""
}

const RE_INICIO_SEMANA = /^(\d{2})\/(\d{2})\/(\d{4})\s*\|\s*(.+)$/;

function paraISO(dia: string, mes: string, ano: string): string {
  return `${ano}-${mes}-${dia}`;
}

function limparTitulo(titulo: string): string {
  // remove a duração "(X min.)" no final, mantém o número da parte —
  // é exatamente o formato esperado no campo "Número da parte" do S-89
  return titulo.replace(/\s*\(\d+\s*min\.?\)\s*$/i, "").trim();
}

function ehPlaceholder(valor: string): boolean {
  const v = valor.trim().toLowerCase();
  return v === "" || v === "nome" || v === "nome/nome" || v.includes("[tema]");
}

function dividirEstudanteAjudante(valor: string): [string, string] {
  const partes = valor.split("/").map((p) => p.trim());
  return [partes[0] ?? "", partes[1] ?? ""];
}

const ROTULOS_UNICOS = new Set([
  "Presidente:",
  "Dirigente da sala B:",
  "Dirigente da sala C:",
  "Oração:",
  "Dirigente/Leitor:",
]);

export async function importarS140(arquivo: File): Promise<DesignacaoS140[]> {
  const XLSX = await import("xlsx");
  const buffer = await arquivo.arrayBuffer();
  const planilha = XLSX.read(buffer, { type: "array" });

  const resultado: DesignacaoS140[] = [];

  for (const nomeAba of planilha.SheetNames) {
    const aba = planilha.Sheets[nomeAba];
    const matriz: unknown[][] = XLSX.utils.sheet_to_json(aba, {
      header: 1,
      defval: "",
      raw: false, // formata datas/horas como string, não precisamos delas
    });

    let dataAtual = "";
    let semanaAtual = "";
    let secaoAtual: "" | "tesouros" | "ministerio" | "vida_crista" = "";
    let oracoesNaSemana = 0;

    const texto = (v: unknown) => String(v ?? "").trim();

    for (const linha of matriz) {
      const colB = texto(linha[0]);
      const colD = texto(linha[2]);
      const colF = texto(linha[4]);
      const colG = texto(linha[5]);
      const colI = texto(linha[7]);
      const colJ = texto(linha[8]);
      const colK = texto(linha[9]);

      // início de uma nova semana
      const inicioSemana = colB.match(RE_INICIO_SEMANA);
      if (inicioSemana) {
        const [, dia, mes, ano, tema] = inicioSemana;
        dataAtual = paraISO(dia, mes, ano);
        semanaAtual = tema.trim();
        secaoAtual = "";
        oracoesNaSemana = 0;
        continue;
      }
      if (!dataAtual) continue; // ainda não achou nenhuma semana

      // marcadores de seção (linha só com o título da seção na col B)
      if (colB === "TESOUROS DA PALAVRA DE DEUS") {
        secaoAtual = "tesouros";
        continue;
      }
      if (colB === "FAÇA SEU MELHOR NO MINISTÉRIO") {
        secaoAtual = "ministerio";
        continue;
      }
      if (colB === "NOSSA VIDA CRISTÃ") {
        secaoAtual = "vida_crista";
        continue;
      }

      // designações únicas (Presidente, Dirigentes de sala, Oração,
      // Estudo Bíblico) — rótulo na coluna J, valor na coluna K
      if (ROTULOS_UNICOS.has(colJ) && !ehPlaceholder(colK)) {
        if (colJ === "Presidente:") {
          resultado.push({
            data_reuniao: dataAtual,
            semana: semanaAtual,
            tipo: "Presidente",
            nome: "Presidente",
            estudante: colK,
            ajudante: "",
            sala: "",
          });
        } else if (colJ === "Dirigente da sala B:") {
          resultado.push({
            data_reuniao: dataAtual,
            semana: semanaAtual,
            tipo: "Dirigente de Sala",
            nome: "Dirigente da Sala B",
            estudante: colK,
            ajudante: "",
            sala: "Sala B",
          });
        } else if (colJ === "Dirigente da sala C:") {
          resultado.push({
            data_reuniao: dataAtual,
            semana: semanaAtual,
            tipo: "Dirigente de Sala",
            nome: "Dirigente da Sala C",
            estudante: colK,
            ajudante: "",
            sala: "Sala C",
          });
        } else if (colJ === "Oração:") {
          oracoesNaSemana++;
          resultado.push({
            data_reuniao: dataAtual,
            semana: semanaAtual,
            tipo: oracoesNaSemana <= 1 ? "Oração Inicial" : "Oração Final",
            nome: oracoesNaSemana <= 1 ? "Oração Inicial" : "Oração Final",
            estudante: colK,
            ajudante: "",
            sala: "",
          });
        } else if (colJ === "Dirigente/Leitor:") {
          const [dirigente, leitor] = dividirEstudanteAjudante(colK);
          resultado.push({
            data_reuniao: dataAtual,
            semana: semanaAtual,
            tipo: "Estudo Bíblico de Congregação",
            nome: limparTitulo(colD) || "Estudo Bíblico de Congregação",
            estudante: dirigente,
            ajudante: leitor,
            sala: "",
          });
        }
        continue;
      }

      // designações com estudante, divididas por sala (col F = rótulo)
      if ((colF === "Estudante:" || colF === "Estudante/Ajudante:") && colD) {
        if (colD.includes("[Tema]")) continue;
        const numeroParte = limparTitulo(colD);
        const comAjudante = colF === "Estudante/Ajudante:";

        const tipo = colD.toLowerCase().includes("leitura da bíblia")
          ? "Leitura da Bíblia"
          : colD.toLowerCase().includes("discurso")
            ? "Discurso"
            : numeroParte.replace(/^\d+\.\s*/, ""); // "Iniciando conversas" etc.

        const salas: [string, string][] = [
          [colG, "Sala C"],
          [colI, "Sala B"],
          [colK, "Salão principal"],
        ];
        for (const [valor, sala] of salas) {
          if (ehPlaceholder(valor)) continue;
          const [estudante, ajudante] = comAjudante
            ? dividirEstudanteAjudante(valor)
            : [valor, ""];
          resultado.push({
            data_reuniao: dataAtual,
            semana: semanaAtual,
            tipo,
            nome: numeroParte,
            estudante,
            ajudante,
            sala,
          });
        }
        continue;
      }

      // partes sem rótulo, nome único na col K (pontos 1/2 de Tesouros,
      // discursos de Nossa Vida Cristã)
      if (/^\d+\./.test(colD) && !ehPlaceholder(colK) && !colD.includes("[Tema]")) {
        const numero = parseInt(colD, 10);
        let tipo = "Nossa Vida Cristã";
        if (secaoAtual === "tesouros") {
          tipo = numero === 1 ? "Tesouros da Palavra de Deus" : "Joias Espirituais";
        }
        resultado.push({
          data_reuniao: dataAtual,
          semana: semanaAtual,
          tipo,
          nome: limparTitulo(colD),
          estudante: colK,
          ajudante: "",
          sala: "",
        });
      }
    }
  }

  return resultado;
}
